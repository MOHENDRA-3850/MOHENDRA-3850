"""
fetch_contributions.py — pull the public contribution calendar HTML
fragment GitHub serves for any profile (no token / GraphQL needed) and
turn it into data/contributions.json with raw days + derived stats.
"""
import sys
import json
import re
from datetime import datetime
import requests
from bs4 import BeautifulSoup

UA = "Mozilla/5.0 (compatible; profile-readme-bot/1.0)"

def fetch(username):
    url = f"https://github.com/users/{username}/contributions"
    r = requests.get(url, headers={"User-Agent": UA}, timeout=20)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")

    days = []
    cells = soup.select("td.ContributionCalendar-day")
    if not cells:
        # newer GitHub markup uses <table> rows of <td> with data-date, or
        # a list of <rect>/<tool-tip> pairs depending on rollout; try both.
        cells = soup.select("[data-date]")

    for c in cells:
        date = c.get("data-date")
        count = c.get("data-count") or c.get("data-level")
        if date is None:
            continue
        try:
            count = int(count) if count is not None else 0
        except ValueError:
            count = 0
        level = c.get("data-level")
        days.append({
            "date": date,
            "count": count,
            "level": int(level) if level is not None else None,
        })

    days.sort(key=lambda d: d["date"])
    return days

def derive_stats(days):
    if not days:
        return {}
    total = sum(d["count"] for d in days)
    # current streak (from most recent day backwards)
    cur_streak = 0
    for d in reversed(days):
        if d["count"] > 0:
            cur_streak += 1
        else:
            break
    # longest streak
    longest = streak = 0
    for d in days:
        if d["count"] > 0:
            streak += 1
            longest = max(longest, streak)
        else:
            streak = 0
    best = max(days, key=lambda d: d["count"])
    return {
        "total_last_year": total,
        "current_streak": cur_streak,
        "longest_streak": longest,
        "best_day": {"date": best["date"], "count": best["count"]},
        "generated_at": datetime.utcnow().isoformat() + "Z",
    }

if __name__ == "__main__":
    username = sys.argv[1] if len(sys.argv) > 1 else "MOHENDRA-3850"
    days = fetch(username)
    stats = derive_stats(days)
    out = {"username": username, "days": days, "stats": stats}
    with open("data/contributions.json", "w") as f:
        json.dump(out, f, indent=2)
    print(f"fetched {len(days)} days for {username}; total={stats.get('total_last_year')}")
