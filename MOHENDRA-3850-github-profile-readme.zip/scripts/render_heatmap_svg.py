"""
render_heatmap_svg.py — draw data/contributions.json as the classic
53-week x 7-day grid of rounded boxes, revealed diagonally on load.
"""
import json
import sys
from datetime import datetime

PALETTE = ["#161b22", "#0e4429", "#006d32", "#26a641", "#39d353", "#69f0a0"]
BOX = 11
GAP = 3
CELL = BOX + GAP
LEFT_PAD = 28      # room for day-of-week labels
TOP_PAD = 20        # room for month labels
LEGEND_H = 26
FOOTER_H = 20
TEXT_COLOR = "#8b949e"
FONT = '"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace'

MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
DOW_LABELS = {1: "Mon", 3: "Wed", 5: "Fri"}  # python weekday(): Mon=0 ... use isoweekday-ish mapping below

def level_for(count):
    if count == 0:
        return 0
    if count <= 2:
        return 1
    if count <= 4:
        return 2
    if count <= 7:
        return 3
    if count <= 10:
        return 4
    return 5

def build(data_path, out_path):
    data = json.load(open(data_path))
    days = data["days"]
    stats = data.get("stats", {})
    username = data.get("username", "")

    # bucket days into weeks (columns), GitHub weeks start on Sunday
    by_date = {d["date"]: d for d in days}
    if not days:
        raise SystemExit("no contribution data")

    first = datetime.strptime(days[0]["date"], "%Y-%m-%d")
    # back up to the most recent Sunday on/before `first`
    start = first
    while start.weekday() != 6:  # Sunday
        # python Monday=0..Sunday=6; step back one day
        from datetime import timedelta
        start -= timedelta(1)

    from datetime import timedelta
    last = datetime.strptime(days[-1]["date"], "%Y-%m-%d")
    weeks = []
    cursor = start
    week = []
    month_marks = []  # (week_index, label)
    seen_months = set()
    week_idx = 0
    while cursor <= last:
        ds = cursor.strftime("%Y-%m-%d")
        d = by_date.get(ds, {"date": ds, "count": 0})
        if cursor.weekday() == 6 and len(week) > 0:
            weeks.append(week)
            week = []
            week_idx += 1
        key = (cursor.year, cursor.month)
        if cursor.day <= 7 and key not in seen_months:
            seen_months.add(key)
            month_marks.append((week_idx, MONTHS[cursor.month - 1]))
        week.append(d)
        cursor += timedelta(1)
    if week:
        weeks.append(week)

    n_weeks = len(weeks)
    grid_w = n_weeks * CELL
    grid_h = 7 * CELL
    width = LEFT_PAD + grid_w + 12
    height = TOP_PAD + grid_h + LEGEND_H + FOOTER_H

    parts = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">'
    )
    parts.append(
        f'<style>text{{font-family:{FONT};font-size:10px;fill:{TEXT_COLOR};}}'
        f'.stats{{font-size:11px;}}</style>'
    )

    # month labels
    for wi, label in month_marks:
        x = LEFT_PAD + wi * CELL
        parts.append(f'<text x="{x}" y="{TOP_PAD - 8}">{label}</text>')

    # day-of-week labels (Mon/Wed/Fri) — row index where Sunday=0
    dow_row = {1: "Mon", 3: "Wed", 5: "Fri"}
    for row, label in dow_row.items():
        y = TOP_PAD + row * CELL + BOX
        parts.append(f'<text x="0" y="{y}">{label}</text>')

    max_delay = 0
    for wi, wk in enumerate(weeks):
        for di, d in enumerate(wk):
            lvl = level_for(d["count"])
            x = LEFT_PAD + wi * CELL
            y = TOP_PAD + di * CELL
            delay = (wi + di) * 0.012
            max_delay = max(max_delay, delay)
            color = PALETTE[lvl]
            title = f'{d["count"]} contribution{"s" if d["count"]!=1 else ""} on {d["date"]}'
            parts.append(
                f'<rect x="{x}" y="{y}" width="{BOX}" height="{BOX}" rx="2.5" ry="2.5" '
                f'fill="{color}" opacity="0" transform="translate(-6,-6)">'
                f'<title>{title}</title>'
                f'<animate attributeName="opacity" from="0" to="1" dur="0.4s" '
                f'begin="{delay:.3f}s" fill="freeze"/>'
                f'<animateTransform attributeName="transform" type="translate" '
                f'from="-6 -6" to="0 0" dur="0.4s" begin="{delay:.3f}s" fill="freeze" '
                f'calcMode="spline" keySplines="0.25 0.1 0.25 1"/>'
                f'</rect>'
            )

    # legend
    leg_y = TOP_PAD + grid_h + 16
    parts.append(f'<text x="{LEFT_PAD}" y="{leg_y}">Less</text>')
    lx = LEFT_PAD + 32
    for i, c in enumerate(PALETTE):
        parts.append(f'<rect x="{lx + i*14}" y="{leg_y-9}" width="{BOX}" height="{BOX}" rx="2.5" fill="{c}"/>')
    parts.append(f'<text x="{lx + len(PALETTE)*14 + 6}" y="{leg_y}">More</text>')

    # stats footer
    total = stats.get("total_last_year", sum(d["count"] for d in days))
    streak = stats.get("current_streak", 0)
    longest = stats.get("longest_streak", 0)
    footer = f'{total} contributions in the last year  ·  current streak {streak}  ·  longest streak {longest}'
    parts.append(f'<text class="stats" x="{LEFT_PAD}" y="{height-6}">{footer}</text>')

    parts.append('</svg>')
    with open(out_path, "w") as f:
        f.write("\n".join(parts))
    print(f"wrote {out_path}  ({width}x{height}px, {n_weeks} weeks, reveal ~{max_delay+0.4:.2f}s)")

if __name__ == "__main__":
    data_path = sys.argv[1] if len(sys.argv) > 1 else "data/contributions.json"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "contrib-heatmap.svg"
    build(data_path, out_path)
