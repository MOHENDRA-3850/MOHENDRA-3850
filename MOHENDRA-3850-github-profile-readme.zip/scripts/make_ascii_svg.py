"""
make_ascii_svg.py — convert a prepped grayscale photo into a monochrome
ASCII-art SVG that "types" itself in row by row (SMIL clip-path wipe).
No JS, no external CSS — everything lives inside the SVG so GitHub renders it.
"""
import sys
from PIL import Image

RAMP = " .`:-=+*cs#%@"        # bright (sparse) -> dark (dense); leading space = background
FONT_SIZE = 8
CHAR_W = FONT_SIZE * 0.6      # monospace advance width
LINE_H = FONT_SIZE * 1.0
FILL = "#8b949e"              # GitHub muted gray, reads well in light + dark mode
BG = "transparent"

def image_to_grid(path, cols=100):
    img = Image.open(path).convert("L")
    w, h = img.size
    # account for monospace cell aspect ratio (~0.6 wide : 1 tall) so the
    # portrait doesn't look squashed
    rows = max(1, round(cols * (h / w) * (CHAR_W / FONT_SIZE)))
    small = img.resize((cols, rows), Image.LANCZOS)
    px = small.load()
    grid = []
    for y in range(rows):
        row = []
        for x in range(cols):
            brightness = px[x, y]  # 0=black .. 255=white
            idx = int((255 - brightness) / 255 * (len(RAMP) - 1))
            row.append(RAMP[idx])
        grid.append("".join(row))
    return grid

def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def build_svg(grid, out_path):
    cols = max(len(r) for r in grid)
    rows = len(grid)
    width = cols * CHAR_W
    height = rows * LINE_H
    stagger = 0.025   # seconds between each row starting its wipe
    wipe_dur = 0.35

    parts = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:.0f}" height="{height:.0f}" '
        f'viewBox="0 0 {width:.0f} {height:.0f}">'
    )
    parts.append(f'<rect width="100%" height="100%" fill="{BG}"/>')
    parts.append(
        f'<style>text{{font-family:"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace;'
        f'font-size:{FONT_SIZE}px;fill:{FILL};white-space:pre;}}</style>'
    )
    parts.append("<defs>")
    for i in range(rows):
        begin = i * stagger
        y0 = i * LINE_H
        parts.append(f'<clipPath id="row{i}">')
        parts.append(
            f'<rect x="0" y="{y0:.2f}" width="0" height="{LINE_H:.2f}">'
            f'<animate attributeName="width" from="0" to="{width:.0f}" '
            f'dur="{wipe_dur}s" begin="{begin:.3f}s" fill="freeze" '
            f'calcMode="spline" keySplines="0.25 0.1 0.25 1"/>'
            f'</rect>'
        )
        parts.append('</clipPath>')
    parts.append("</defs>")

    for i, row in enumerate(grid):
        y = (i + 1) * LINE_H - LINE_H * 0.22
        begin = i * stagger
        safe_row = esc(row)
        parts.append(f'<g clip-path="url(#row{i})">')
        parts.append(f'<text x="0" y="{y:.2f}" xml:space="preserve">{safe_row}</text>')
        # cursor block riding the wipe edge for this row
        cursor_w = CHAR_W
        parts.append(
            f'<rect y="{i*LINE_H:.2f}" width="{cursor_w:.2f}" height="{LINE_H:.2f}" '
            f'fill="{FILL}" opacity="0.55">'
            f'<animate attributeName="x" from="0" to="{width - cursor_w:.0f}" '
            f'dur="{wipe_dur}s" begin="{begin:.3f}s" fill="freeze" '
            f'calcMode="spline" keySplines="0.25 0.1 0.25 1"/>'
            f'<animate attributeName="opacity" from="0.55" to="0" '
            f'dur="0.15s" begin="{begin + wipe_dur:.3f}s" fill="freeze"/>'
            f'</rect>'
        )
        parts.append("</g>")

    parts.append("</svg>")
    svg = "\n".join(parts)
    with open(out_path, "w") as f:
        f.write(svg)
    print(f"wrote {out_path}  ({cols}x{rows} chars, {width:.0f}x{height:.0f}px, "
          f"finishes ~{(rows-1)*stagger + wipe_dur:.2f}s)")

if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "prepped.png"
    out = sys.argv[2] if len(sys.argv) > 2 else "mohendra-ascii.svg"
    cols = int(sys.argv[3]) if len(sys.argv) > 3 else 95
    grid = image_to_grid(src, cols=cols)
    build_svg(grid, out)
