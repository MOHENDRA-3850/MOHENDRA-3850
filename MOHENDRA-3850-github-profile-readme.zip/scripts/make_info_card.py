"""
make_info_card.py — a neofetch-style panel (title bar + colored key/value
rows) that fades in line by line next to the ASCII portrait.
"""
import os

WIDTH = 490
PAD_X = 22
TITLE_H = 34
ROW_H = 27
FONT = '"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace'

TITLE = "mohendra@github"
FIELDS = [
    ("Now",        "ECE Undergrad @ JIS College of Engineering"),
    ("Role",       "Research Intern @ IISc Bangalore + VLED Lab, IIT Ropar"),
    ("Focus",      "AI/ML · Signal Processing · Embedded Systems"),
    ("Publications", "3 papers — nano-electronics, quantum wires, EEG-BCI"),
    ("Building",   "PACS (anti-jamming comms) · AQUILUS-X (amphibious UAV/UUV)"),
    ("Honor",      "India Book of Records, 2025"),
]

ACCENT = "#39d353"   # GitHub green for keys
VALUE_COLOR = "#c9d1d9"
DIM = "#8b949e"
PANEL_BG = "#0d1117"
BORDER = "#30363d"

def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

def build(out_path, static=False):
    rows = len(FIELDS)
    height = TITLE_H + rows * ROW_H + 18
    stagger = 0.12
    fade_dur = 0.35

    parts = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{height}" '
        f'viewBox="0 0 {WIDTH} {height}">'
    )
    parts.append(
        f'<style>'
        f'.k{{font-family:{FONT};font-size:13px;fill:{ACCENT};font-weight:600;}}'
        f'.v{{font-family:{FONT};font-size:13px;fill:{VALUE_COLOR};}}'
        f'.t{{font-family:{FONT};font-size:12.5px;fill:{DIM};}}'
        f'</style>'
    )
    # panel background
    parts.append(
        f'<rect x="0" y="0" width="{WIDTH}" height="{height}" rx="10" '
        f'fill="{PANEL_BG}" stroke="{BORDER}" stroke-width="1"/>'
    )
    # title bar
    parts.append(f'<rect x="0" y="0" width="{WIDTH}" height="{TITLE_H}" rx="10" fill="#161b22"/>')
    parts.append(f'<rect x="0" y="{TITLE_H-10}" width="{WIDTH}" height="10" fill="#161b22"/>')
    for i, c in enumerate(["#ff5f56", "#ffbd2e", "#27c93f"]):
        parts.append(f'<circle cx="{18 + i*16}" cy="{TITLE_H/2:.0f}" r="5" fill="{c}"/>')
    parts.append(
        f'<text x="{WIDTH/2:.0f}" y="{TITLE_H/2 + 4:.0f}" text-anchor="middle" class="t">{esc(TITLE)}</text>'
    )
    parts.append(f'<line x1="0" y1="{TITLE_H}" x2="{WIDTH}" y2="{TITLE_H}" stroke="{BORDER}"/>')

    key_col_w = 108
    for i, (k, v) in enumerate(FIELDS):
        y = TITLE_H + 26 + i * ROW_H
        begin = i * stagger
        style = "" if static else (
            f' opacity="0"><animate attributeName="opacity" from="0" to="1" '
            f'dur="{fade_dur}s" begin="{begin:.2f}s" fill="freeze"/>'
            f'<animateTransform attributeName="transform" type="translate" '
            f'from="-8 0" to="0 0" dur="{fade_dur}s" begin="{begin:.2f}s" fill="freeze"/'
        )
        opening = '>' if static else '>'
        parts.append(f'<g{"" if static else " opacity=" + chr(34) + "0" + chr(34)}>')
        if not static:
            parts.append(
                f'<animate attributeName="opacity" from="0" to="1" dur="{fade_dur}s" '
                f'begin="{begin:.2f}s" fill="freeze"/>'
            )
        parts.append(f'<text x="{PAD_X}" y="{y}" class="k">{esc(k)}</text>')
        parts.append(f'<text x="{PAD_X + key_col_w}" y="{y}" class="v">{esc(v)}</text>')
        parts.append('</g>')

    parts.append('</svg>')
    svg = "\n".join(parts)
    with open(out_path, "w") as f:
        f.write(svg)
    print(f"wrote {out_path}  ({WIDTH}x{height}px)")

if __name__ == "__main__":
    static = os.environ.get("STATIC") == "1"
    build("info-card.svg" if not static else "info-card-static.svg", static=static)
