"""
prep_photo.py — turn a raw photo into a clean, high-contrast grayscale
portrait ready for ASCII conversion. No external model downloads:
face detection uses OpenCV's built-in Haar cascade, contrast uses CLAHE.
"""
import sys
import cv2
import numpy as np
from PIL import Image, ImageOps

def prep(src_path, out_path="prepped.png", pad_ratio=0.9):
    img = cv2.imread(src_path)
    if img is None:
        # Handle webp / formats cv2 struggles with via Pillow first
        pil = Image.open(src_path).convert("RGB")
        img = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)

    gray_full = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # --- face-centered crop ---
    cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )
    faces = cascade.detectMultiScale(gray_full, scaleFactor=1.1, minNeighbors=5)

    h, w = gray_full.shape
    if len(faces) > 0:
        # take the largest detected face
        x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
        cx, cy = x + fw / 2, y + fh / 2
        side = int(max(fw, fh) / pad_ratio * 2.1)  # generous padding for shoulders
        x0 = int(max(0, cx - side / 2))
        y0 = int(max(0, cy - side * 0.55))  # keep more room below (shoulders)
        x1 = int(min(w, cx + side / 2))
        y1 = int(min(h, y0 + side * 1.15))
        crop = gray_full[y0:y1, x0:x1]
    else:
        # fallback: center square crop
        side = min(h, w)
        x0, y0 = (w - side) // 2, (h - side) // 2
        crop = gray_full[y0:y0 + side, x0:x0 + side]

    # --- CLAHE local contrast boost ---
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    enhanced = clahe.apply(crop)

    # --- gentle denoise + sharpen for cleaner glyph edges ---
    enhanced = cv2.bilateralFilter(enhanced, d=5, sigmaColor=40, sigmaSpace=40)

    pil_img = Image.fromarray(enhanced)
    pil_img = ImageOps.autocontrast(pil_img, cutoff=1)
    pil_img.save(out_path)
    print(f"wrote {out_path}  ({pil_img.size[0]}x{pil_img.size[1]})")

if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "source-photo.webp"
    out = sys.argv[2] if len(sys.argv) > 2 else "prepped.png"
    prep(src, out)
